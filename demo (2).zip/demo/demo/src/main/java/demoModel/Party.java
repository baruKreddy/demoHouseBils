package demoModel;

public class Party {

}
